import { Injectable } from '@nestjs/common';
import { Interval } from '@nestjs/schedule';
import { ScanService } from './scan.service';
import { ScanGateway } from './scan.gateway';

@Injectable()
export class ScanJob {
  constructor(
    private readonly scanService: ScanService,
    private readonly gateway: ScanGateway,
  ) {}

  @Interval(1000)
  async handleScan() {
    const data = await this.scanService.scanLocal();
    this.gateway.emitScanUpdate(data);
  }
}
